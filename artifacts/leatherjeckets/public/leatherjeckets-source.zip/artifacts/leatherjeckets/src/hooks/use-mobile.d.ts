export function useIsMobile(): boolean;
